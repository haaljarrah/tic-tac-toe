//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package tictactoe;

import java.util.Scanner;

public class TicTacToi {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to 3x3 Tic Tac Toe.");
        System.out.println("Are you wants to start first or not?\nEnter \"y\" for yes and \"n\" for no.\nNOTES\n(X always starts the game)?");
        char whoIsFirst = scan.next().charAt(0);
        User p1 = new User(0, 0);
        Ai ai = new Ai(0, 0);
        if (whoIsFirst == 'y') {
            new Game(p1, ai);
        } else if (whoIsFirst == 'n') {
            new Game(ai, p1);
        }

        Game.startGame();
    }
}
