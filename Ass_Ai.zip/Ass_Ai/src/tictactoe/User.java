package tictactoe;

import java.util.InputMismatchException;
import java.util.Scanner;

public class User extends Player {
    public User(int s, int p) {
        super(s, p);
    }

    @Override
    int enterNum(String p, String o) {

        Scanner in = new Scanner(System.in);
        System.out.println("Enter the number of the place you want to play from 1 to 9");
        while (true) {
            int numInput;

            // Exception handling.
            // numInput will take input from user like from 1 to 9.
            // If it is not in range from 1 to 9.
            // then it will show you an error "Invalid input."
            try {
                numInput = in.nextInt();
                if (!(numInput > 0 && numInput <= 9)) {
                    System.out.println(
                            "Invalid input; re-enter slot number:");
                    continue;
                }
            } catch (InputMismatchException e) {
                System.out.println(
                        "Invalid input; re-enter slot number:");
                continue;
            }
            if (BoardList.chickSlot(numInput))
                return numInput;
            else {
                System.out.println(
                        "Slot already taken; re-enter slot number:");
            }

        }
    }
}
