package tictactoe;
import java.util.Objects;
import java.util.Scanner;

public class Ai extends Player {
    boolean prune = true;
    int p;
    static String player = "X", opponent = "O";

    public Ai(int s, int p) {
        super(s, p);

        Scanner scan = new Scanner(System.in);
        System.out.println("Do you want to play with Alpha-Beta Pruning or not?");
        String m =scan.next();
        if (Objects.equals(s, "no"))
            prune = false;
        else if (Objects.equals(s, "yes")) prune = true;
    }


    // This function returns true if there are moves
// remaining on the board. It returns false if
// there are no moves left to play.
    static Boolean isMovesLeft(String[] board) {
        for (int i = 0; i < 9; i++) {
            if (!Objects.equals(board[i], "_"))
                continue;

            return true;
        }
        return false;
    }

    static int evaluate(String[] b) {

        // Checking for Rows for X or O victory.
        for (int row = 0; row < 9; row += 3) {
            if (Objects.equals(b[row], b[row + 1]) &&
                    Objects.equals(b[row + 1], b[row + 2])) {

                if (Objects.equals(b[row], player))
                    return +10;
                else if (Objects.equals(b[row], opponent))
                    return -10;
            }

        }

        // Checking for Columns for X or O victory.
        for (int col = 0; col < 3; col++) {
            if (Objects.equals(b[col], b[col + 3]) &&
                    Objects.equals(b[col + 3], b[col + 6])) {
                if (Objects.equals(b[col], player))
                    return +10;

                else if (Objects.equals(b[col], opponent))
                    return -10;
            }
        }

        // Checking for Diagonals for X or O victory.
        if (Objects.equals(b[0], b[4]) && Objects.equals(b[4], b[8])) {
            if (Objects.equals(b[0], player))
                return +10;
            else if (Objects.equals(b[0], opponent))
                return -10;
        }

        if (Objects.equals(b[2], b[4]) && Objects.equals(b[4], b[6])) {
            if (Objects.equals(b[2], player))
                return +10;
            else if (b[2].equals(opponent))
                return -10;
        }

        // Else if none of them have won then return 0
        return 0;
    }

    // This is the minimaxWithPruning function. It considers all
// the possible ways the game can go and returns
// the value of the board
    static int minimax(String[] board, Boolean isMax) {
        System.out.println("without pruning");

        int score = evaluate(board);

        // If Maximizer has won the game
        // return his/her evaluated score
        if (score == 10)
            return score;

        // If Minimizer has won the game
        // return his/her evaluated score
        if (score == -10)
            return score;

        // If there are no more moves and
        // no winner then it is a tie
        if (!isMovesLeft(board))
            return 0;

        // If this maximizer's move
        int best;
        if (isMax) {
            best = -1000;

            // Traverse all cells
            for (int i = 0; i < 9; i++) {

                // Check if cell is empty
                if (Objects.equals(board[i], "_")) {
                    // Make the move
                    board[i] = player;

                    // Call minimaxWithPruning recursively and choose
                    // the maximum value
                    best = Math.max(best, minimax(board, false));
                    board[i] = "_";


                }

            }
        }

        // If this minimizer's move
        else {
            best = 1000;

            // Traverse all cells
            for (int i = 0; i < 9; i++) {

                if (Objects.equals(board[i], "_")) {
                    board[i] = opponent;

                    best = Math.min(best, minimax(board, true));
                    board[i] = "_";

                }

            }
        }
        return best;
    }

    static int minimaxWithPruning(String[] board,
                                  int depth, int alpha,
                                  int beta, Boolean isMax) {
        int score = evaluate(board);

        // If Maximizer has won the game
        // return his/her evaluated score
        if (score == 10)
            return score;

        // If Minimizer has won the game
        // return his/her evaluated score
        if (score == -10)
            return score;

        // If there are no more moves and
        // no winner then it is a tie
        if (!isMovesLeft(board))
            return 0;
        // If this maximizer's move
        int best;
        if (isMax) {
            best = -1000;

            // Traverse all cells
            for (int i = 0; i < 9; i++) {

                // Check if cell is empty
                if (Objects.equals(board[i], "_")) {
                    // Make the move
                    board[i] = player;

                    // Call minimaxWithPruning recursively and choose
                    // the maximum value
                    best = Math.max(best, minimaxWithPruning(board,
                            depth + 1, alpha, beta, false));

                    // Undo the move
                    board[i] = "_";
                    alpha = Math.max(alpha, best);
                    if (beta <= alpha) break;
                }

            }
        }


        // If this minimizer's move
        else {
            best = 1000;

            // Traverse all cells
            for (int i = 0; i < 9; i++) {

                // Check if cell is empty
                if (Objects.equals(board[i], "_")) {
                    // Make the move
                    board[i] = opponent;

                    // Call minimaxWithPruning recursively and choose
                    // the minimum value
                    int s = minimaxWithPruning(board,
                            depth + 1, alpha, beta, true);
                    best = Math.min(best, s);
                    // Undo the move
                    board[i] = "_";
                    beta = Math.min(beta, s);
                    if (beta <= alpha) break;

                }

            }
        }
        return best;
    }

    // This will return the best possible
// move for the player
    int findBestMove(String[] board) {
        int bestVal = -1000;
        p = -1;

        for (int i = 0; i < 9; i++) {

            // Check if cell is empty
            if (Objects.equals(board[i], "_")) {
                // Make the move
                board[i] = player;

                // compute evaluation function for this
                int moveVal;
                if (prune) {
                    moveVal = minimaxWithPruning(board, 0, -10000, 10000, false);
                    System.out.println("pruning");

                } else {
                    moveVal = minimax(board, false);
                    System.out.println("without pruning");

                }
                board[i] = "_";

                // If the value of the current move is
                // more than the best value, then update
                // best/
                if (moveVal > bestVal) {
                    p = i;
                    bestVal = moveVal;
                }
            }

        }

        return p;
    }

    @Override
    int enterNum(String p, String o) {
        String[] br = new String[9];
        for (int i = 0; i < 9; i++) {
            if (Objects.equals(BoardList.list[i], "X") || Objects.equals(BoardList.list[i], "O"))
                br[i] = BoardList.list[i];
            else {
                br[i] = "_";
            }

        }
        player = p;
        opponent = o;
        return findBestMove(br) + 1;
    }
}
