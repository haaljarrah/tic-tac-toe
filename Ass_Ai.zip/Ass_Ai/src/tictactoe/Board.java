package tictactoe;
import org.jetbrains.annotations.Nullable;

import java.util.*;
class BoardList {
    static String[] list;
    static String winner;


    BoardList() {
        winner = null;

        list = new String[9];
        for (int i = 0; i < 9; i++) {
            list[i] = String.valueOf(i + 1);
        }
        printBoard();

    }


    static @Nullable String checkWinner() {
        for (int a = 0; a < 8; a++) {
            String line = switch (a) {
                case 0 -> BoardList.list[0] + BoardList.list[1] + BoardList.list[2];
                case 1 -> BoardList.list[3] + BoardList.list[4] + BoardList.list[5];
                case 2 -> BoardList.list[6] + BoardList.list[7] + BoardList.list[8];
                case 3 -> BoardList.list[0] + BoardList.list[3] + BoardList.list[6];
                case 4 -> BoardList.list[1] + BoardList.list[4] + BoardList.list[7];
                case 5 -> BoardList.list[2] + BoardList.list[5] + BoardList.list[8];
                case 6 -> BoardList.list[0] + BoardList.list[4] + BoardList.list[8];
                case 7 -> BoardList.list[2] + BoardList.list[4] + BoardList.list[6];
                default -> null;
            };

            //For X winner
            if (line.equals("XXX")) {
                return "X";
            }

            // For O winner
            else if (line.equals("OOO")) {
                return "O";
            }
        }

        for (int a = 0; a < 9; a++) {
            if (Arrays.asList(BoardList.list).contains(
                    String.valueOf(a + 1))) {
                break;
            } else if (a == 8) {
                return "draw";
            }
        }

        return null;
    }


    public static void printBoard() {
        System.out.println("|---|---|---|");
        System.out.println("| " + BoardList.list[0] + " | "
                + BoardList.list[1] + " | " + BoardList.list[2]
                + " |");
        System.out.println("|-----------|");
        System.out.println("| " + BoardList.list[3] + " | "
                + BoardList.list[4] + " | " + BoardList.list[5]
                + " |");
        System.out.println("|-----------|");
        System.out.println("| " + BoardList.list[6] + " | "
                + BoardList.list[7] + " | " + BoardList.list[8]
                + " |");
        System.out.println("|---|---|---|");
        System.out.println("================================");
        System.out.println("================================");
        System.out.println("================================");

    }

    static boolean chickSlot(int pos) {
        return BoardList.list[pos - 1].equals(
                String.valueOf(pos));

    }

    void enterNumber(int pos, String s) {
        BoardList.list[pos - 1] = s;
        printBoard();
        winner = checkWinner();

    }
}